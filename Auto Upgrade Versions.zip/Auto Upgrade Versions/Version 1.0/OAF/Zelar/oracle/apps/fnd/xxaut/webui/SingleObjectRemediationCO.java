/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package Zelar.oracle.apps.fnd.xxaut.webui;

import java.sql.CallableStatement;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

/**
 * Controller for ...
 */
public class SingleObjectRemediationCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
          
       
           if (pageContext.getParameter("Clear") != null)
                {
                  System.out.println("Clear Opertation");       
                  pageContext.setForwardURL("OA.jsp?page=/Zelar/oracle/apps/fnd/xxaut/webui/SingleObjectRemediationPG", 
                                            null, OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                            null, null, false, null, 
                                            OAWebBeanConstants.IGNORE_MESSAGES);
                }
                

    
           
                  {
           if (pageContext.getParameter("Submit") != null)
           {
               System.out.println("Submit button clicked:" );
           {
           OADBTransaction oadbtransaction = am.getOADBTransaction();
                 CallableStatement oraclecallablestatement;
                                     System.out.println("Called CallableStatement:" );
                
                  String   CustomSchema = pageContext.getParameter("CustomSchema");
                    String ObjectName = pageContext.getParameter("ObjectName");
                   String  ObjectType = pageContext.getParameter("ObjectType");                       
                    String ApplicationObjectSchemaObject = pageContext.getParameter("ApplicationObjectSchemaObject");
                   String  DestinationDirectory = pageContext.getParameter("DestinationDirectory");
                   String  RemediationFileName = pageContext.getParameter("RemediationFileName");
                   String  DBUsernamePassword = pageContext.getParameter("DBUsernamePassword");
                                     String  UserActivityName = pageContext.getParameter("UserActivityName");
                                     String  UserName = pageContext.getParameter("UserName");
                                     String  InstanceVersion = pageContext.getParameter("InstanceVersion");
                               
                               
                                 
                     System.out.println("DBUsernamePassword  is:" + DBUsernamePassword + 
                                        "and ObjectType is:" + ObjectType);

                     oraclecallablestatement = 
                         oadbtransaction.createCallableStatement("{call aut_obj_remedi_concurrent(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10)}", 
                                                                 0);
                     try
                     {
                       oraclecallablestatement.setString(1, ObjectName);
                       oraclecallablestatement.setString(2, ObjectType);
                       oraclecallablestatement.setString(3, ApplicationObjectSchemaObject);
                       oraclecallablestatement.setString(4, DestinationDirectory);
                       oraclecallablestatement.setString(5, CustomSchema);
                       oraclecallablestatement.setString(6, RemediationFileName);
                       oraclecallablestatement.setString(7, DBUsernamePassword);
                       oraclecallablestatement.setString(8, UserActivityName);
                       oraclecallablestatement.setString(9, UserName);
                       oraclecallablestatement.setString(10, InstanceVersion);
                                     
              

                       oraclecallablestatement.execute();

                 
                       am.getOADBTransaction().commit();
                                     oraclecallablestatement.close();
                                      OAException confirmMessage = 
                    new OAException(" Single Object Remediation submitted   ", 
                                    OAException.CONFIRMATION);
                pageContext.putDialogMessage(confirmMessage);

                                                } catch (Exception e)
                                                {
                                                  throw OAException.wrapperException(e);
                                                }
                                 }
           }
                  }
  }

}
