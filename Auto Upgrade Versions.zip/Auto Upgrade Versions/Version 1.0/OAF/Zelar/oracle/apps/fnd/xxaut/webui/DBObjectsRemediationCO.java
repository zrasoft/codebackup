/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package Zelar.oracle.apps.fnd.xxaut.webui;

import java.sql.CallableStatement;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;


/**
 * Controller for ...
 */
public class DBObjectsRemediationCO extends OAControllerImpl {
    public static final String RCS_ID = "$Header$";
    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

    /**
     * Layout and page setup logic for a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        OAApplicationModule am = 
            (OAApplicationModule)pageContext.getApplicationModule(webBean);
        OAViewObject vo = (OAViewObject)am.findViewObject("SearchVO1");

        String UserName = "";
        UserName = pageContext.getParameter("UserName");
        //        System.out.println("UserName nameis:" + UserName);

        String UserActivityName = "";
        UserActivityName = pageContext.getParameter("UserActivityName");

        Date frmDate = (Date)pageContext.getCurrentDBDate();

        OAMessageDateFieldBean bean = 
            (OAMessageDateFieldBean)webBean.findChildRecursive("FromDate");
        OAMessageDateFieldBean bean1 = 
            (OAMessageDateFieldBean)webBean.findChildRecursive("ToDate");

        if (bean != null) {
            bean.setValue(pageContext, frmDate);
        }
        if (bean1 != null) {
            bean1.setValue(pageContext, frmDate);
        }
        if (UserName != null) {


            if (UserActivityName != null)

            {
                vo.setWhereClause("1=1 and upper(USER_NAME)='" + 
                                  UserName.toUpperCase() + "' " + 
                                  " and upper(USER_ACTIVITY_NAME)='" + 
                                  UserActivityName.toUpperCase() + "' ");
                vo.executeQuery();
            }
        }

    }

    /**
     * Procedure to handle form submissions for form elements in
     * a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {
        super.processFormRequest(pageContext, webBean);
        OAApplicationModule am = pageContext.getApplicationModule(webBean);

        OAViewObject vo = (OAViewObject)am.findViewObject("SearchVO1");
        if (pageContext.getParameter("Clear") != null)
             {
               System.out.println("Clear Opertation");       
               pageContext.setForwardURL("OA.jsp?page=/Zelar/oracle/apps/fnd/xxaut/webui/DatabaseObjectsRemediationPG", 
                                         null, OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                         null, null, false, null, 
                                         OAWebBeanConstants.IGNORE_MESSAGES);
             }
             
        if (pageContext.getParameter("Cancle") != null)
             {
               System.out.println("Clear Opertation");       
               pageContext.setForwardURL("OA.jsp?page=/Zelar/oracle/apps/fnd/xxaut/webui/DatabaseObjectsRemediationPG", 
                                         null, OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                         null, null, false, null, 
                                         OAWebBeanConstants.IGNORE_MESSAGES);
             }
        
            if (pageContext.getParameter("Search") != null)
            {
                System.out.println(" Search button clicked");
            {
                String From_date = "";
                String To_Date = "";
                From_date = pageContext.getParameter("FromDate");
                To_Date = pageContext.getParameter("ToDate");
                System.out.println("From date is:" + From_date + 
                                   " and To Date is :" + To_Date);

                String UserName = "";
                UserName = pageContext.getParameter("UserName");
                System.out.println(" UserName is:" + UserName);

                String UserActivityName = "";
                UserActivityName = pageContext.getParameter("UserActivityName");
                System.out.println("UserActivityName  is:" + UserActivityName);

                if (From_date != null && To_Date != null) {
                    System.out.println("Enter Query Part");
                    vo.setWhereClause("1=1 and trunc(CREATION_DATE)>='" + 
                                      From_date + "' and trunc(CREATION_DATE)<='" + 
                                      To_Date + "' " + " and USER_NAME=nvl('" + 
                                      UserName + "',USER_NAME) " + 
                                      "and USER_ACTIVITY_NAME=nvl('" + 
                                      UserActivityName + "',USER_ACTIVITY_NAME)");
                    System.out.println("The  Query is :" + vo.getQuery());
                    vo.executeQuery();
                }


                DateFormat formatter;
                //   DateFormat formatter2;
                java.util.Date date;
                java.util.Date date2;
                if (From_date != null) {
                    try {
                        formatter = new SimpleDateFormat("dd-MM-yyyy");
                        date = formatter.parse(From_date);
                        date2 = formatter.parse(To_Date);
                        System.out.println("format date is:" + date);
                        if (date.after(date2)) {
                            throw new OAException("From Date is Greater than To Date. Please provide From date value is equal or less than of To Date value", 
                                                  OAException.WARNING);
                        }

                    } catch (ParseException e) {
                        // TODO
                    }


                }
            }
        }
        
        {
        if (pageContext.getParameter("Submit") != null)
        {
            System.out.println("Submit button clicked:");
        {
            OADBTransaction oadbtransaction = am.getOADBTransaction();
            CallableStatement oraclecallablestatement;
            System.out.println("Called CallableStatement:");

            String DestinationDirectory = 
                pageContext.getParameter("DestinationDirectory");
            String CustomSchema = pageContext.getParameter("CustomSchema");
            String RemediationFileName = 
                pageContext.getParameter("RemediationFileName");
            String DBUsernamePassword = 
                pageContext.getParameter("DBUsernamePassword");
            String ObjectTypes = pageContext.getParameter("ObjectTypes");
            String UsrActivityName = 
                pageContext.getParameter("UsrActivityName");
            String UsrName = pageContext.getParameter("UsrName");
            String ObjectName = pageContext.getParameter("ObjectName");
            String SchemaName = pageContext.getParameter("SchemaName");


            System.out.println("In Save CustomSchema  is:" + CustomSchema + 
                               "and ObjectType is:" + ObjectTypes);

            oraclecallablestatement = 
                    oadbtransaction.createCallableStatement("{call AUT_REMEDIATION_CONCURRENT(:1,:2,:3,:4,:5,:6,:7,:8,:9)}", 
                                                            0);
            try {
                oraclecallablestatement.setString(1, DestinationDirectory);
                oraclecallablestatement.setString(2, CustomSchema);
                oraclecallablestatement.setString(3, RemediationFileName);
                oraclecallablestatement.setString(4, DBUsernamePassword);
                oraclecallablestatement.setString(5, ObjectTypes);
                oraclecallablestatement.setString(6, ObjectName);
                oraclecallablestatement.setString(7, SchemaName);
                oraclecallablestatement.setString(8, UsrActivityName);
                oraclecallablestatement.setString(9, UsrName);


                oraclecallablestatement.execute();


                am.getOADBTransaction().commit();
                oraclecallablestatement.close();
OAException confirmMessage = 
                    new OAException(" Remediation for DB objects submitted   ", 
                                    OAException.CONFIRMATION);
                pageContext.putDialogMessage(confirmMessage);

            } catch (Exception e) {
                throw OAException.wrapperException(e);
            }
        }
        
        }
                                   
        }
       


    }

}
