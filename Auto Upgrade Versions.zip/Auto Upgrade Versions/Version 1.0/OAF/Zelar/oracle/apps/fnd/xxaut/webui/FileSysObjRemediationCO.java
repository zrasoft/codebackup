/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package Zelar.oracle.apps.fnd.xxaut.webui;

import com.sun.org.apache.bcel.internal.generic.ObjectType;

import java.sql.CallableStatement;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

/**
 * Controller for ...
 */
public class FileSysObjRemediationCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
      if (pageContext.getParameter("Clear") != null)
             {
               pageContext.forwardImmediatelyToCurrentPage(null, false, null);
             }
                  
            if (pageContext.getParameter("Submit") != null)
                System.out.println("Submit button clicked:" );
            {
            OADBTransaction oadbtransaction = am.getOADBTransaction();
                  CallableStatement oraclecallablestatement;
                                      System.out.println("Called CallableStatement:" );
                 
                   String   DBUsernamePassword = pageContext.getParameter("DBUsernamePassword");
                     String CustomTop = pageContext.getParameter("CustomTop");
                    String  ConvertTargetPath = pageContext.getParameter("ConvertTargetPath");                       
                     String FileTypeRiceW = pageContext.getParameter("FileTypeRiceW");
                    String  FilePrefix = pageContext.getParameter("FilePrefix");
                                  String  ObjectType = pageContext.getParameter("ObjectType");
                                        String  RemediationPathTargetPath = pageContext.getParameter("RemediationPathTargetPath");
                                          String  InstanceVersion = pageContext.getParameter("InstanceVersion");
           
                      
                                  
                      System.out.println("In Save DBUsernamePassword  is:" + DBUsernamePassword + 
                                         "and ObjectType is:" + ObjectType);

                      oraclecallablestatement = 
                          oadbtransaction.createCallableStatement("{call AUT_REMEDI_RICEW_CONCURRENT(:1,:2,:3,:4,:5,:6,:7,:8,:9)}", 
                                                                  0);
                      try
                      {
                        oraclecallablestatement.setString(1, DBUsernamePassword);
                        oraclecallablestatement.setString(2, CustomTop);
                        oraclecallablestatement.setString(3, ConvertTargetPath);
                        oraclecallablestatement.setString(4, ObjectType);
                        oraclecallablestatement.setString(5, FilePrefix);
                                        oraclecallablestatement.setString(6, ConvertTargetPath);
                                        oraclecallablestatement.setString(7, RemediationPathTargetPath);
                                        oraclecallablestatement.setString(8, InstanceVersion);
                                                     oraclecallablestatement.setString(9, FileTypeRiceW);
            
               

                        oraclecallablestatement.execute();

                  
                        am.getOADBTransaction().commit();
                                      oraclecallablestatement.close();
OAException confirmMessage = 
                    new OAException(" Remediation for File system  objects submitted   ", 
                                    OAException.CONFIRMATION);
                pageContext.putDialogMessage(confirmMessage);

                                                 } catch (Exception e)
                                                 {
                                                   throw OAException.wrapperException(e);
                                                 }
                                           
                                  }
                                  
      
            
  }

}
