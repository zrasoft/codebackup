CREATE OR REPLACE FORCE VIEW APPS.AUT_CUSTOM_OBJECT_DETAILS_V (
   USER_ACTIVITY_NAME,
   USER_NAME,
   CREATION_DATE,
   CREATED
)
AS
   SELECT   DISTINCT user_activity_name,
                     user_name,
                     TRUNC (creation_date),
                     TO_CHAR (creation_date, 'DD-MM-YYYY')
     FROM   AUT_CUSTOM_OBJECT_DETAILS;

exit;
