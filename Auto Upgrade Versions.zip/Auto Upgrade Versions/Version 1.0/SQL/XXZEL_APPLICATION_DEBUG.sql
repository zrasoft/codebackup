CREATE TABLE APPS.XXZEL_APPLICATION_DEBUG
(
  SEQUENCE_NUMBER    NUMBER,
  DEBUG_TIMESTAMP    TIMESTAMP(6) WITH LOCAL TIME ZONE NOT NULL,
  PROCESS_NAME       VARCHAR2(100 BYTE)         NOT NULL,
  PROCEDURE_NAME     VARCHAR2(100 BYTE)         NOT NULL,
  DEBUG_MESSAGE      CLOB                       NOT NULL,
  STAGE              VARCHAR2(30 BYTE)          NOT NULL,
  REQUEST_ID         NUMBER                     DEFAULT (-1),
  LAST_UPDATE_LOGIN  NUMBER                     DEFAULT (-1),
  CREATED_BY         NUMBER                     NOT NULL,
  CREATION_DATE      DATE                       NOT NULL,
  LAST_UPDATE_DATE   DATE                       NOT NULL,
  LAST_UPDATED_BY    NUMBER                     NOT NULL,
  ATTRIBUTE1         VARCHAR2(500 BYTE),
  ATTRIBUTE2         VARCHAR2(500 BYTE),
  ATTRIBUTE3         VARCHAR2(500 BYTE),
  ATTRIBUTE4         VARCHAR2(500 BYTE),
  ATTRIBUTE5         VARCHAR2(500 BYTE),
  ATTRIBUTE6         VARCHAR2(500 BYTE),
  ATTRIBUTE7         VARCHAR2(500 BYTE),
  ATTRIBUTE8         VARCHAR2(500 BYTE),
  ATTRIBUTE9         VARCHAR2(500 BYTE),
  ATTRIBUTE10        VARCHAR2(500 BYTE)
)
LOB (DEBUG_MESSAGE) STORE AS SECUREFILE (
  TABLESPACE  APPS_TS_TX_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  NOCACHE
  LOGGING
      STORAGE    (
                  INITIAL          128K
                  NEXT             128K
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                  FLASH_CACHE      DEFAULT
                  CELL_FLASH_CACHE DEFAULT
                 ))
TABLESPACE APPS_TS_TX_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            NEXT             128K
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

exit;